// Develop a structure to represent each of each of the following geometric objects : 
//Rectangle ,Traingle,Circle.Compare Structure and Union with suitable example

#include <stdio.h>
#include <stdlib.h>

struct rectangle {
    int length;
    int width;
} rect;

struct triangle {
    int base;
    int height;
} tri;

struct circle {
    int radius;
} circ;

int main () {
    int ch;
    float area;
    printf("Enter 1: Rectangle\n");
    printf("Enter 2: Triangle\n");
    printf("Enter 3: Circle\n");
    scanf("%d", &ch);

    switch(ch) {
        case 1:
            printf("Enter L and B\n");
            scanf("%d%d", &rect.length, &rect.width);
            area = rect.width * rect.length;
            printf("area: %f", area);
            break;
        case 2:
            printf("Enter B and H\n");
            scanf("%d%d", &tri.base, &tri.height);
            area = 0.5 * tri.base * tri.height;
            printf("area: %f", area);
            break;

        case 3:
            printf("Enter Radius\n");
            scanf("%d", &circ.radius);
            area = 3.14 * circ.radius * circ.radius;
            printf("area: %f", area);
            break;

        default:
            printf("error");
    }
}