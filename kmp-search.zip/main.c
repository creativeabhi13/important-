
// kmp search or kmp mather or failure or 4th pattern matching algorithm

#include<stdio.h>
#include<string.h>
char txt[100],pat[100];
int i=0;
int j=0;
void PiArray(char* pat, int M, int* Pi); 


void KMPSearch(char* pat, char* txt) 
{ 
	int M = strlen(pat); 
	int N = strlen(txt); 

 
	int Pi[M]; 

	
	PiArray(pat, M, Pi); 

	
	while (i < N) { 
		if (pat[j] == txt[i]) { 
			j++; 
			i++; 
		} 

		if (j == M) { 
			printf("pattern  is found at location%d ", i+1 - j); 
			j = Pi[j - 1]; 
		} 

		
		else if (i < N && pat[j] != txt[i]) { 
			 
			if (j != 0) 
				j = Pi[j - 1]; 
			else
				i = i + 1; 
		} 
	} 
} 

 
void PiArray(char* pat, int M, int* Pi) 
{ 
	int len=0;

	Pi[0] = 0;
	 
	int i = 1; 
	while (i < M) { 
		if (pat[i] == pat[len]) { 
			len++; 
			Pi[i] = len; 
			i++; 
		} 
		else  
		{ 
			
			if (len != 0) { 
				len = Pi[len - 1]; 

				
			} 
			else 
			{ 
				Pi[i] = 0; 
				i++; 
			} 
		} 
	} 
} 


int main() 
{ 
	 
	
   printf("Enter the Text here\n");
   scanf("%s",txt);
   printf("Enter the Pattern\n");
   scanf("%s",pat);
   
	KMPSearch(pat, txt); 
	return 0; 
} 


