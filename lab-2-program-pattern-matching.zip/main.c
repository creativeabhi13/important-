/*Design, Develop and Implement a Program in C for the following operations on Strings.
a. Read a main String (STR), a Pattern String (PAT) and a Replace String (REP)
b. Perform Pattern Matching Operation: Find and Replace all occurrences of PAT in
STR with REP if PAT exists in STR. Report suitable messages in case PAT does not
exist in STR
Support the program with functions for each of the above operations. Don't use Built-in
functions. */
// MY NAME FOLLOWED WITH MY USN IS ABHISHEK KUMAR & 1JT19CS002

#include<stdio.h>
char str[100],pat[50],rep[50],ans[50];
int c=0,m=0,i=0,j=0,k,flag=0;
void stringmatch();
int main()
{
    printf("MY NAME IS ABHISHEK KUMAR AND USN IS 1JT19CS002\n");
    printf("enter the main string \n");
    gets(str);
    printf("enter the pattern string\n");
    gets(pat);
    printf("enter the replace string\n");
    gets(rep);
    stringmatch();
 if(flag==1)
    {
        printf("resultant string is %s\n",ans);
    }
   else
   {
       printf("pattern is not found\n");
   }
    
}
void stringmatch()
{
while(str[c] !='\0')
{
 if(str[m] == pat[i])
{
 i++;
 m++;
if(pat[i] == '\0')
{             
flag = 1;
     for(k=0; rep[k]!='\0'; k++, j++)
     {
         ans[j] = rep[k];
     }

     i = 0;
     c = m;

    }
  }
else
{
  ans[j]= str[c];
        j++;
        c++;
        m=c;
        i=0;
     }
  }
   ans[j]='\0';
}

