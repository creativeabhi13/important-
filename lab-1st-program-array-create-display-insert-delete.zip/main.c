/*Design, Develop and Implement a menu driven Program in C for the following array
operations.
a. Creating an array of N Integer Elements
b. Display of array Elements with Suitable Headings
c. Inserting an Element (ELEM) at a given valid Position (POS)
d. Deleting an Element at a given valid Position (POS)
e. Exit.
Support the program with functions for each of the above operations.*/
// MY NAME FOLLOWED WITH USN IS ABHISEK KUMAR  & 1JT19CS002
#include<stdio.h>
#include<stdlib.h>
int a[100],pos,element;
int n=0,i;
void create();
void display();
void insert();
void del();
int main()
{
    int choice;
    while(1)
    {
        printf("MY USN IS 1JT19CS002 AND MY NAME IS ABHISHEK KUMAR ");
    printf("\n enter the choices\n");
    printf("\n 1. an array of n integer\n");
    printf("\n 2. display the array element \n");
    printf("\n 3. insert the element in given pos\n");
    printf("\n 4. delete the element in the given pos\n");
    printf("5. exit\n");
    printf("ente your choices\n");
    scanf("%d",&choice);
   switch(choice)
   {
       case 1:create();
       break;
       case 2: display();
       break;
       case 3: insert();
       break;
       case 4: del();
       break;
       case 5: exit(1);
       break;
       default:
          printf("enter the valid choices\n"); 
      } 
    }
}


void create()
{
  printf("enter the number of element\n");
  scanf("%d",&n);
  printf("enter the elements\n");
  for(i=0;i<n;i++)
  {
      scanf("%d",&a[i]);
  }
}
void display()
{
    if(n==0) {
         printf("no element to dislay\n");
         }
       
       
           printf("\n array element are\n");
           for(i=0;i<n;i++)
           printf("a[%d]=%d\t",i,a[i]);
       
         
}
void insert()
{
    if(n!=5)
    {
        printf("array is full\n. insertion is not possible\n");
    }
    do
    {
        printf("\n enter the valid postion where the element to be inserted\n");
        scanf("%d",&pos);

    } while (pos>n);
    printf("enter thevalue to be inserted\n");
    scanf("%d",&element);
    for(i=n-1;i>=pos;i--)
    {
        a[i+1]=a[i];
        
    }
    a[pos]=element;
    n=n+1;
    display();
    
}
void del()
{
    if(n==0)
    {
        printf("array is empty and no element to delete  \n");
    }
    do
    {
        printf("\n enter the valid postion where the element to be delted\n");
        scanf("%d",&pos);

    } while (pos>=n);
    printf("enter the value to be deleted\n");
    scanf("%d",&element);
    for(i=n-1;i>=pos;i--)
    {
        a[i]=a[i+1];
        
    }
    a[pos]=element;
    n=n-1;
    display();
}




