// 3rd pattern matching algo or n find pattern matching 
#include<stdio.h>
#include<string.h>
int np(char *,char *);

int  main()
{
    char string[100],pat[100];
    int pos;
    printf("enter the string\n");
    gets(string);
    printf("enter the pattren\n");
    gets(pat);
    pos = np(string,pat);
    if(pos!=-1)
    {
        printf("pattren is found at position %d\n",pos);

    }
    else
    {
        printf("pattren not available");
    }
    
}
int np(char *string,char *pat)
{
    int i,j,start=0;
    int lasts=strlen(string)-1;
    int lastp=strlen(pat)-1;
    int endmatch = lastp;
    for(i=0;endmatch<=lasts;endmatch++,start++)
    {
        if(string[endmatch]==pat[lastp])
        {
            for(j=0,i=start;j<lastp && string[i]==pat[j];i++,j++)
            {
                
            }
        }
        if(j==lastp)
        {
            return start;
        }

    }
    return -1;

}