// stack implementation
/*STACK of Integers (Array Implementation of Stack with maximum size MAX)
a. Push an Element on to Stack
b. Pop an Element from Stack
c. Demonstrate how Stack can be used to check Palindrome
d. Demonstrate Overflow and Underflow situations on Stack
e. Display the status of Stack
f. Exit 
*/

#include<stdio.h>
#include<stdlib.h>
#define MAX 5
int s[MAX];
int top=-1;
void push(int item);
int pop();
void palindrome();
void display();
int main()
{
    int choice,item;
      while(1)
      {
          printf("\n.............................MENU..........................\n");
          printf("1. Push an element to  the stack and overflow\n ");
          printf("2. Pop an element from the stack and underflow\n");
          printf("3. palindrome\n");
          printf("4. exit");
          printf("enter your choice: ");
          scanf("%d",&choice);
        switch(choice)
        {
            case 1: printf("\n enter the element to be pushed. \n");
            scanf("%d",&item);
            push(item);
            case 2: item=pop();
              if(item !=-1)
              printf("\n element popped out is %d:",item);
              break;
            case 3: palindrome();
            break;
            case 4: display();
            break;
            case 5: exit(1);
            default : 
            printf("\n enter the valid choices\n");
        }
      }
}
void push(int item)
{
    if(top==MAX-1)
    {
        printf("\n .......stack is overflow......\n");
        return;
    }
    top=top+1;
    s[top]=item;
}

int pop()
{
    int item;
    if(top==-1)
    {
        printf("\n..................stack is underflow................\n");
        return;
    }
    item=s[top];
    top=top-1;
    return item;
}
void display()
{
            int i;
            if(top == -1)
            {
                        printf("\n~~~~Stack is empty~~~~");
                        return;
            }
            printf("\nStack elements are:\n ");
            for(i=top; i>=0 ; i--)
            printf("| %d |\n", s[i]);
}

void palindrome()
{
            int flag=1,i;
            printf("\nStack content are:\n");
            for(i=top; i>=0 ; i--)
                        printf("| %d |\n", s[i]);

            printf("\nReverse of stack content are:\n");
            for(i=0; i<=top; i++)
                        printf("| %d |\n", s[i]);

            for(i=0; i<=top/2; i++)
            {
                        if( s[i] != s[top-i] )
                        {
                                    flag = 0;
                                    break;
                        }
            }
            if(flag == 1)
            {
                        printf("\nIt is palindrome number");
            }
            else
            {
                        printf("\nIt is not a palindrome number");
            }
}


