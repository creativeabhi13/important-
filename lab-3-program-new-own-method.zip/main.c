/*Design, Develop and Implement a menu driven Program in C for the following operations
on STACK of Integers (Array Implementation of Stack with maximum size MAX)
a. Push an Element on to Stack
b. Pop an Element from Stack
c. Demonstrate how Stack can be used to check Palindrome
d. Demonstrate Overflow and Underflow situations on Stack
e. Display the status of Stack
f. Exit.
Support the program with appropriate functions for each of the above operations */

#include<stdio.h>
#include<stdlib.h>
#define MAX 4
int stack[MAX], item;

int ch, top = -1, count = 0, status = 0;

void push (int stack[], int item);

int pop (int stack[]);

void palindrome (int stack[]);

void display (int stack[]);

int
main () 
{
  
printf ("MY NAME IS ABHISHEK KUMAR AND USN IS 1JT19CS002\n");
  
while (1)
    
    {
      
printf (".....................MENU..................... :\n");
      
printf ("1. push the element to the stack\n");
      
printf ("2. pop the element from the stack\n");
      
printf ("3. check whether it is palindrome or not\n");
      
printf ("4.exit\n");
      
printf ("choose your choice\n");
      
scanf ("%d", &ch);
      
switch (ch)
	
	{
	
case 1:
	  printf ("enter the element to be pushed\n");
	  
scanf ("%d", &item);
	  
push (stack, item);
	  
display (stack);
	  
break;
	
case 2:
	  item = pop (stack);
	  
display (stack);
	  
break;
	
case 3:
	  palindrome (stack);
	  
break;
	
case 4:
	  exit (0);
	  
break;
	
default:
	  printf ("invalid option");
	
 
}
    
}
  

}


void
push (int stack[], int item) 
{
  
if (top == (MAX - 1))
    
printf ("stack is overflow\n");
  
  else
    
    {
      
stack[++top] = item;
      
status++;
    
}

}


int
pop (int stack[]) 
{
  
int ret;
  
if (top == -1)
    
printf ("stack is underflow\n");
  
  else
    
    {
      
ret = stack[top--];
      
status--;
      
printf ("\nPopped element is %d", ret);
    
}

}


void
palindrome (int stack[]) 
{
  
int i, temp;
  
temp=status;
  
for (i = 0; i < temp; i++)
    
    {
      
if (stack[i] == pop(stack))
	
count++;
    
}
  
if (temp == count)
    
printf ("\nStack contents are Palindrome");
  
  else
    
     printf ("\nStack contents are not palindrome");
    
}


void
display (int stack[]) 
{
  
int i;
  
printf ("\nThe stack contents are:");
  
if (top == -1)
    
printf ("\nStack is Empty");
  
  else
    {
      
for (i = top; i >= 0; i--)
	
printf ("\n ------\n| %d |", stack[i]);
      
printf ("\n");
    
}

}




