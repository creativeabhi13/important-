#include<stdio.h>
#include<string.h>

int main()
{
    char P[100];
    char T[100];
    int R,S,K,L,MAX,INDEX;
    printf("Enter some text\n");
    gets(T);
    
    printf("Enter a string to find\n");
    gets(P);
    R=strlen(P);
    S=strlen(T);
    K=0;  
    MAX=S-R;
    while(K<=MAX)
    {
        for(L=0;L<R;++L)
        
            if(P[L]!=T[K+L-1])
            break;
            if(L==R)
            {
                INDEX=K;
                break;
            }
           else
           
               K=K+1;
    }
   if(K>MAX)
    INDEX=-1;
    printf("P IS :%s\n",P);
    printf("\n T : %s",T);
    if(INDEX!=-1)
    {
       printf("\n index of P in T is  %d",INDEX);
    }
   else {
   
       printf("\n P does not exist in T\n");
   
   }

}